


<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit ticket</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('tickets.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <?php
    $status=array("NEW"=>"NEW","INPROGRESS"=>"INPROGRESS","child"=>"child","parent"=>"parent","SOLVED"=>"SOLVED");
    
    
    $Priority=array("HIGH"=>"HIGH","MEDIUM"=>"MEDIUM","LOW"=>"LOW");
   
    ?>
    <?php
    $user= auth()->user();
    ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <?php echo Form::model($ticket, ['method' => 'PATCH','route' => ['tickets.update', $ticket->id]]); ?>

    	<?php echo csrf_field(); ?>
         <div class="row">
		    <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Ticket Name:</strong>
                    <?php echo Form::text('Bugname', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

		        </div>
		    </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Priority:</strong>
            <?php echo Form::select('Priority', [null=>'please select'] + $Priority,$ticket->Priority, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Description:</strong>
                    <?php echo Form::text('Description', null, array('placeholder' => 'Description','class' => 'form-control')); ?>

		        </div>
		    </div>
		    <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Status:</strong>
            <?php echo Form::select('status',[null=>'please select'] + $status,$ticket->status, ['class' => 'form-control']); ?>

                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Solution:</strong>
                    <?php echo Form::text('solution', null, array('placeholder' => 'Solution','class' => 'form-control')); ?>

		        </div>
		    </div>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>assign to:</strong>
            <?php echo Form::select('assignedto',$users,null, ['class' => 'form-control']); ?>

                </div>
            </div>
            <?php endif; ?>
            
		    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
		            <button type="submit" class="btn btn-primary">Submit</button>
		    </div>
		</div>


        <?php echo Form::close(); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bugtracker\resources\views/tickets/edit.blade.php ENDPATH**/ ?>