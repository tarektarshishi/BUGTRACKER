


<?php $__env->startSection('content'); ?>
<?php
use App\Models\Project;
?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-create')): ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New ticket</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('tickets.index')); ?>"> Back</a>
            </div>
        </div>
    </div>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php
    $status=array("NEW"=>"NEW","child"=>"child","parent"=>"parent");
    
    
    $Priority=array("HIGH"=>"HIGH","MEDIUM"=>"MEDIUM","LOW"=>"LOW");
   
    ?>
    <?php
    $user= auth()->user();
    
    ?>
        <?php echo Form::open(array('route' => 'tickets.store','method'=>'POST')); ?>

    	<?php echo csrf_field(); ?>
         <div class="row">
		    <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Ticket Name:</strong>
                    <?php echo Form::text('Bugname', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

		        </div>
		    </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Priority:</strong>
            <?php echo Form::select('Priority',[null=>'please select'] + $Priority,'please select', ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Description:</strong>
                    <?php echo Form::text('Description', null, array('placeholder' => 'Description','class' => 'form-control')); ?>

		        </div>
		    </div>
            
		    <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Status:</strong>
            <?php echo Form::select('status', [null=>'please select'] + $status,'please select', ['class' => 'form-control']); ?>

                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Project:</strong>
            <?php echo Form::select('projectid',$projects,[],array('class' => 'form-control','multiple')); ?>

                </div>
            </div>
           
            <input type="hidden" value="<?php echo e($user->id); ?>" name="submittedby" />
        
		    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
		            <button type="submit" class="btn btn-primary">Submit</button>
		    </div>
		</div>


        <?php echo Form::close(); ?>


    
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bugtracker\resources\views/tickets/create.blade.php ENDPATH**/ ?>