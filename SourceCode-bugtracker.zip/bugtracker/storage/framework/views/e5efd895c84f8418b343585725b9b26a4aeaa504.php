


<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>create Profile</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('tickets.index')); ?>"> Back</a>
            </div>
        </div>
    </div>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
<?php echo Form::open(array('route' => 'profiles.store','method'=>'POST','files' => true)); ?>

<input type="hidden" value="<?php echo e($id); ?>" name="user_id" />
    <div class="col-xs-12 col-sm-12 col-md-12">
        <label for="exampleFormControlFile1">Select Profile Picture</label>
        <input type="file" class="form-control-file" name="image">
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Nationality:</strong>
                    <?php echo Form::text('Nationality', null, array('placeholder' => 'Nationality','class' => 'form-control')); ?>

		        </div>
		</div>
        <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>city:</strong>
                    <?php echo Form::text('city', null, array('placeholder' => 'city','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Area:</strong>
                    <?php echo Form::text('Area', null, array('placeholder' => 'Area','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>street:</strong>
                    <?php echo Form::text('street', null, array('placeholder' => 'street','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>Building:</strong>
                    <?php echo Form::text('Building', null, array('placeholder' => 'Building','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>floor:</strong>
                    <?php echo Form::text('floor', null, array('placeholder' => 'floor','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>mobile number:</strong>
                    <?php echo Form::number('mobile', null, array('placeholder' => '76123456','class' => 'form-control')); ?>

		        </div>
		    </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
		        <div class="form-group">
		            <strong>phone number:</strong>
                    <?php echo Form::number('phone', null, array('placeholder' => '08123456','class' => 'form-control')); ?>

		        </div>
		    </div>
        
        <div class="col-xs-12 col-sm-12 col-md-12">
        <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bugtracker\resources\views/profiles/create.blade.php ENDPATH**/ ?>