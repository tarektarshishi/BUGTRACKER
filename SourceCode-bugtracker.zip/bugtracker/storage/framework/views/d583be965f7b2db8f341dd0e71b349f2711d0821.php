


<?php $__env->startSection('content'); ?>
<?php
use App\Models\User;
use App\Models\Project;

?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-list')): ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show ticket</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('tickets.index')); ?>"> Back</a>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Ticket Name:</strong>
                <?php echo e($ticket->Bugname); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Priority:</strong>
                <span class="badge badge-primary">
                <?php echo e($ticket->Priority); ?>

                </span>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                <?php echo e($ticket->Description); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>AssignedTo:</strong>
                <span class="badge badge-info">
                <?php echo e(USER::find( $ticket->assignedto)->name); ?>

                </span>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Status:</strong>
                <span class="badge badge-danger">
                <?php echo e($ticket->status); ?>

                </span>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Solution:</strong>
                <?php echo e($ticket->solution); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Submitted By:</strong>
                <?php echo e(USER::find( $ticket->submittedby)->name); ?>

            </div>
        </div>
        
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>ProjectName:</strong>
                <?php echo e(Project::find($ticket->projectid)->ProjectName); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bugtracker\resources\views/tickets/show.blade.php ENDPATH**/ ?>