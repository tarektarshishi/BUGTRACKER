


<?php $__env->startSection('content'); ?>
<?php
use App\Models\User;
use App\Models\Project;
$user= auth()->user();
?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-list')): ?>

<div class="container-fluid">
<div class="card shadow">
<div class="card-header py-3">
    <div class="pull-left">
     <p class="text-primary m-0 font-weight-bold">tickets</p>
     </div>
            
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-create')): ?>
                <a class="btn btn-success" href="<?php echo e(route('tickets.create')); ?>"> Create New ticket</a>
                <?php endif; ?>
            </div>
        </div>
    
    

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('fail')): ?>
    <div class="alert alert-danger">
    <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
    <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
  <table class="table my-0" id="dataTable">
     <thead>
        <tr>
            <th>ID</th>
            <th>Ticket Name</th>
            <th>Project Name</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Assigned to</th>
            <th>Submitted by</th>
            <th width="500">Action</th>
        </tr>
    </thead>
    <tbody>
	    <?php $__currentLoopData = $ticketsall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($ticket->id); ?></td>
	        <td><?php echo e($ticket->Bugname); ?></td>
            <td><?php echo e(Project::find($ticket->projectid)->ProjectName); ?></td>
	        <td> <label class="badge badge-primary"><?php echo e($ticket->Priority); ?></label></td>
	        <td> <label class="badge badge-danger"><?php echo e($ticket->status); ?></label></td>
            <td><span class="badge badge-success"><?php echo e(USER::find( $ticket->assignedto)->name); ?></span></td>
            <td><?php echo e(USER::find( $ticket->submittedby)->name); ?></td>
	        <td width="500">
                <form action="<?php echo e(route('tickets.destroy',$ticket->id)); ?>" method="POST">
                    <div class="links">
                    <a class="btn btn-info" href="<?php echo e(route('tickets.show',$ticket->id)); ?>">Show</a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>
                    <?php if($user->id==$ticket->assignedto): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('tickets.edit',$ticket->id)); ?>">Edit</a>
                    <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('tickets.edit',$ticket->id)); ?>">Edit</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-delete')): ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <?php endif; ?>
                    </div>
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-create')): ?>
     
<div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
  <table class="table my-0" id="dataTable">
  <thead>
        <tr>
            <th>ID</th>
            <th>Ticket Name</th>
            <th>Project Name</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Assigned to</th>
            <th>Submitted by</th>
            <th width="500">Action</th>
        </tr>
    </thead>
    <tbody>
	    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($ticket->id); ?></td>
	        <td><?php echo e($ticket->Bugname); ?></td>
            <td><?php echo e(Project::find($ticket->projectid)->ProjectName); ?></td>
	        <td> <label class="badge badge-primary"><?php echo e($ticket->Priority); ?></label></td>
	        <td> <label class="badge badge-danger"><?php echo e($ticket->status); ?></label></td>
            <td><span class="badge badge-success"><?php echo e(USER::find( $ticket->assignedto)->name); ?></span></td>
            <td><?php echo e(USER::find( $ticket->submittedby)->name); ?></td>
	        <td width="500">
                <form action="<?php echo e(route('tickets.destroy',$ticket->id)); ?>" method="POST">
                    <div class="links">
                    <a class="btn btn-info" href="<?php echo e(route('tickets.show',$ticket->id)); ?>">Show</a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>
                    <?php if($user->id==$ticket->assignedto): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('tickets.edit',$ticket->id)); ?>">Edit</a>
                    <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('tickets.edit',$ticket->id)); ?>">Edit</a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-delete')): ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <?php endif; ?>
                    </div>
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
    
    <?php endif; ?>
    <?php echo $ticketsall->links(); ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bugtracker\resources\views/tickets/index.blade.php ENDPATH**/ ?>